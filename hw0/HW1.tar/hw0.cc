#include <iostream>
using namespace std;
int main() {
// Knock Knock
cout << "Knock Knock\nWho's There\n"
<< "Nana.\n" << "Nana who?\n" << "Nana your business!\n";
    return 0;
}